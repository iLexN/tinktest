[![Build Status](https://travis-ci.org/iLexN/tinktest.svg?branch=master)](https://travis-ci.org/iLexN/tinktest)
[![Coverage Status](https://coveralls.io/repos/github/iLexN/tinktest/badge.svg?branch=master)](https://coveralls.io/github/iLexN/tinktest?branch=master)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/iLexN/tinktest/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/iLexN/tinktest/?branch=master)

* phpunit test result : https://travis-ci.org/iLexN/tinktest
* code cover result : https://coveralls.io/github/iLexN/tinktest
* code quality result : https://scrutinizer-ci.com/g/iLexN/tinktest/

# file structure
* please read file-structure.txt

# api
* please read api.txt

