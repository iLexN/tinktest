<?php

return [
    'logConfig'=> [
            'name' => 'app',
            'path' => __DIR__.'/../logs/'.date('Y-m-d').'.log',
    ],
];
