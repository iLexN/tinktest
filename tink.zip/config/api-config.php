<?php

return [
    'apiConfig' => [
        'base_uri' => 'http://handy.travel',
    ],
];
