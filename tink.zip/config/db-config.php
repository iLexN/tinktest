<?php

return [
    'dbConfig' => [
        'host'     => 'localhost', //dev
        'database' => 'tinktest',
        'user'     => 'root',
        'password' => '',
        'logging'  => true,
    ],
];
