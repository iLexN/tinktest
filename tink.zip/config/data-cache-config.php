<?php

return [
    'dataCacheConfig'=> [
        'path' => __DIR__.'/../cache/data',
        //'expiresAfter'=>3600
        'expiresAfter'=> 1,
    ],
];
