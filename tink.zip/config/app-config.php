<?php

return [
    'settings' => [
        'displayErrorDetails' => true,
        //'routerCacheDisabled' => false,
        //'routerCacheFile' => __DIR__ . '/../cache/route.cache',
        'determineRouteBeforeAppMiddleware' => true,
    ],
];
